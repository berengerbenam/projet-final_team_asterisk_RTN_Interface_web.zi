<?php 
	// inclure le fichier connexion.php
	include("../bd/connexion.php");

	// lorsque le boutton enregistrer est cliqué 
	if (isset($_POST['valider'])) {
		extract($_POST); // elle extrait tous les champs du formulaire

		// empty() vérifie si le champs entré est vide
		if (empty($numcompte) || empty($telephone) || empty($prenom) 
			|| empty($nom) || empty($credit)) {
			$message = "veuillez renseigner tous les champs";
		}else{

			// requette d'insertion dans la table client
			$insert=$connexion->PREPARE("INSERT INTO client(numcompte,tel,prenom,nom,credit,dateajout) VALUES(?,?,?,?,?,NOW())");
			$insert->EXECUTE([$numcompte,$telephone,$prenom,$nom,$credit,]);

			if ($insert) {
			 header('location:../affichage/listeclient.php');
			}
		}
	}

?>