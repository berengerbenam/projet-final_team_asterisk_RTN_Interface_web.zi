<?php
	include("../bd/connexion.php");
	$tel=$_REQUEST['tel'];
	$chemin=$_REQUEST['chemin'];
	$doc="../record/$tel";
// Verifier l'existence du dossier
if(!file_exists($doc)){
    // Tentative de création du répertoire
    if(mkdir($doc)){
        echo "Répertoire créé avec succès.";
    } else{
        echo "ERREUR : Le répertoire n'a pas pu être créé.";
    }
} else{
    echo "ERREUR : Le répertoire existe déjà.";
}
            // requette d'insertion dans la table enregistrement
            $insert=$connexion->PREPARE("INSERT INTO enregistrement(tel,chemin,date) VALUES(?,?,NOW())");
            $insert->EXECUTE([$tel,$chemin]);
?>