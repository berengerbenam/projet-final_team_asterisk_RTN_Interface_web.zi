<?php
include('../bd/connexion1.php');
        // lorsque le boutton enregistrer est cliqué 
    if (isset($_POST['valider'])) {
        $prenom = $_POST['prenom'];
        $telephone = $_POST['telephone'];
        $nom = $_POST['nom'];
        $password = $_POST['password'];
        $boite = $telephone."@default";
        $prenomnom="$prenom $nom";
        $nomcomplet=$prenomnom." "."<".$telephone.">";

        // empty() vérifie si le champs entré est vide
        if (empty($prenom) || empty($telephone) || empty($nom) 
            || empty($password)) {
            $message = "veuillez renseigner tous les champs";
        }else{

            $insert = "INSERT INTO ps_aors(id, max_contacts, qualify_frequency) VALUES('$telephone','30','30')";
            $connexion->exec($insert);


            $insert = "INSERT INTO ps_auths (id, auth_type, password, username) VALUES ('$telephone', 'userpass','$password','$telephone')";
            $connexion->exec($insert);

           $insert = "INSERT INTO ps_endpoints (id, transport, aors, auth, context, disallow, allow, direct_media, deny, permit, mailboxes,callerid) VALUES ('$telephone', 'transport-udp', '$telephone', '$telephone', 'rtn', 'all', 'ulaw,alaw,gsm,vp8,h263,h264', 'no', '0.0.0.0/0', '0.0.0.0/0', '$boite','$nomcomplet')";
            $connexion->exec($insert);

            if ($insert) {
             header('location:../affichage/listecomptepjsip.php');
            }
    }
}
?>
