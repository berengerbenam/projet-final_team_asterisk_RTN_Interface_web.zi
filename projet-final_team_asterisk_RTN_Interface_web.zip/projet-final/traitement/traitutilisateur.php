<?php 
	// inclure le fichier connexion.php
	include("../bd/connexion.php");

	// lorsque le boutton enregistrer est cliqué 
	if (isset($_POST['valider'])) {
		extract($_POST); // elle extrait tous les champs du formulaire

		// empty() vérifie si le champs entré est vide
		if (empty($prenom) || empty($nom) || empty($matricule) 
			|| empty($password) || empty($typecompte)) {
			$message = "veuillez renseigner tous les champs";
		}else{

			// requette d'insertion dans la table client
			$insert=$connexion->PREPARE("INSERT INTO utilisateurs(prenom,nom,matricule,password,typecompte,dateajout) VALUES(?,?,?,?,?,NOW())");
			$insert->EXECUTE([$prenom,$nom,$matricule,$password,$typecompte,]);

			if ($insert) {
			 header('location:../affichage/listeutilisateur.php');
			}
		}
	}

?>