<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	 <link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css">
	<title></title>
</head>
<body style="background-color:white;">
<br><br>	
<div class="offset-1 my-4">
<div class="panel panel-primary  col-md-5 col-md-offset-3 ">
                <div class="panel panel-heading">
                        <h1 align="center">Se Connecter</h1>
                </div>
                <div class="panel panel-body">
			<form action="" method="POST" class="form" >
				<div class="form-group">
					<label for="matricule" class="label-control">LOGIN</label>
					<input type="text" class="form-control" name="matricule">
				</div>
				<div class="form-group">
					<label for="password" class="label-control">MOT DE PASSE</label>
					<input type="password" class="form-control" name="password">
				</div>
				<div class="form-group" align="center">
					<button class="btn btn-success" type="submit" name="valider">SE CONNECTER</button>
					<button class="btn btn-danger" type="reset">Annuler</button>
				</div>
			</form>
		</div>
	</div>
</div>
</div>
</body>
</html>
<?php
session_start();
include("bd/connexion.php");

// lorsque le boutton valider a été cliqué
if (isset($_POST['valider'])) {
	 	$matricule = $_POST['matricule'];
        $password = $_POST['password'];
	// on selectionne les utilisateur avec une condition WHERE
	$select = "SELECT * FROM utilisateurs WHERE matricule= '$matricule' AND password = '$password'";
	$execut = $connexion->query($select);
	$result = $execut->fetch(PDO::FETCH_OBJ);
	// on verifie si ça correspond avec un utilisateur dans la bd
	if ($result->typecompte == "admin") {

		$_SESSION["user"] = $result;

		header('location:menu/accueil.php');

	}elseif($result->typecompte == "simple") {

		$_SESSION["user"] = $result;

		header('location:menu/espace.php');
		
	}else{
		 $msg="Le login ou le mot de passe incorrecte";
		 $url="../index.php";
		header("location:parametre/message.php?msg=$msg&color=r&url=$url");
	}
}
?>