
<?php
define("SERVER","localhost");
?>

