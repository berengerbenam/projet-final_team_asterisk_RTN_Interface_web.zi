<?php
function prenomnomtel($callerid)
{
        $liste=explode("<",trim($callerid));
        $prenomnom=$liste[0];
        $tabcomplet=explode(" ",$prenomnom);
        $l=count($tabcomplet);
        $prenom="";
        $n=$l-1;
        for ($i=0; $i<$n-1; $i++){
        $prenom=$prenom." ".$tabcomplet[$i];
        }
        $nom=$tabcomplet[$n-1];
        $telsup=$liste[1];
        $telsanssup=strtr($telsup,">"," ");
        $tel=trim($telsanssup);
	$result=array($prenom,$nom,$tel);
	return($result);
}
//print_r(prenomnomtel("Boubacar Diop <1000>"));
?>
