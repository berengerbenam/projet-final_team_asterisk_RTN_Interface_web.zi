<!DOCTYPE html>
<html>
<head>
	<title>titre</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style1.css">
<style>
		a{
			font-size: 50px;
		}
		.body{
			background:url("img/lo.jpg");
		}
	</style>
</head>
<body class="body">
	 <div class="horloge">
        <div class="heures"></div>
        <div class="date"></div>
    </div>
    		<h3 align="center">
			<a href="login.php">
			<button class="btn btn-succees" style="font-size: 40px;">Connectez-vous</button></a>
		</h3>
		<script src="js/script.js"></script>
</body>
</html>