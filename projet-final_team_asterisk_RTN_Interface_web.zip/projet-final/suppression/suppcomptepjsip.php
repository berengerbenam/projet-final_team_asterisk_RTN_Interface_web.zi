<?php
include('../bd/connexion1.php');

	if (isset($_GET['id'])) {
 
    $id = $_GET['id'];
 
    $delete = "DELETE  FROM ps_endpoints WHERE id = ?";
 
    $resultat = $connexion->prepare($delete);
 
    $resultat->execute([$id]);

	$delete1 = "DELETE  FROM ps_auths WHERE id = ?";
 
    $resultat1 = $connexion->prepare($delete1);
 
    $resultat1->execute([$id]);


    $delete2 = "DELETE  FROM ps_aors WHERE id = ?";
 
    $resultat2 = $connexion->prepare($delete2);
 
    $resultat2->execute([$id]);

	if ($resultat && $resultat1 && $resultat2) {
			header("location:../affichage/listecomptepjsip.php");
	}else{ 
		echo "La suppression n'as pas marché";

	}
 }

?>
