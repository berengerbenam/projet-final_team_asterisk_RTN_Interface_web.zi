<?php
require('../bd/connexion.php');
if (isset($_GET['id'])) {
 
    $id = $_GET['id'];
 
    $delete = "DELETE  FROM utilisateurs WHERE id = ?";
 
    $results = $connexion->prepare($delete);
 
    $results->execute([$id]);
    
    header('Location:../affichage/listeutilisateur.php');
}