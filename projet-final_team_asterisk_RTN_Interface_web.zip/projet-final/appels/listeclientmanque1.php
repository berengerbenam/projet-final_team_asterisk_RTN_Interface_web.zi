<?php
include("parametre/parametre.php");

function database()
{
    $conn = new PDO("mysql: host=localhost;dbname=rtn","root", "");
    return $conn;

    return $conn;
}

function lecture()
{
    $conn = database();
    $req = "SELECT * FROM client";
    $stmt = $conn->query($req);
    $tab = $stmt->fetchAll();
    return $tab;
}

function irilosi($tel)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://".SERVER.":8088/ari/channels?endpoint=Local/s@banque&extension=".$tel."&context=rtn&priority=1&timeout=30&api_key=asterisk:passer&callerId=RTN");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    curl_close($ch);
}

function lecturetel($tel)
{
    $conn = database();
    $req = "SELECT numcompte, tel, prenom, nom FROM client WHERE tel = :tel";
    $execute = $conn->prepare($req);
    $execute->execute(['tel' => $tel]);
    $tab = $execute->fetchAll();
    return $tab;
}

$tab = lecture();

$conn = database();
$req4 = "TRUNCATE TABLE clientmanque";
$stmt4 = $conn->query($req4);
foreach ($tab as $ligne) {
    $tel = $ligne['tel'];
    $req2 = "SELECT * FROM enregistrement WHERE tel = :tel";
    $execute2 = $conn->prepare($req2);
    $execute2->execute(['tel' => $tel]);
    if ($execute2->rowCount() == 0) {
        $tabclient = lecturetel($tel);
        $prenom = $tabclient[0]['prenom'];
        $nom = $tabclient[0]['nom'];
        $numcompte = $tabclient[0]['numcompte'];
        $tel = $tabclient[0]['tel'];
        $req3 = "INSERT INTO clientmanque (numcompte, tel, prenom, nom) VALUES (:numcompte, :tel, :prenom, :nom)";
        $execute3 = $conn->prepare($req3);
        $execute3->execute(['numcompte' => $numcompte, 'tel' => $tel, 'prenom' => $prenom, 'nom' => $nom]);
    }
}

header("location:../affichage/listeclientmanque2.php");
?>
