<?php 
include("../parametre/parametre.php");

function database()
{
  $conn = new PDO("mysql: host=localhost; dbname=rtn","root", "");
  return $conn;
}
function lecture()
{
     $connexion=database();
     $select = "SELECT * FROM client";
     $execute = $connexion->query($select);
     $results = $execute->fetchALL(PDO::FETCH_ASSOC);
}

function irilosi($tel)
{
       $ch = curl_init();
       curl_setopt($ch, CURLOPT_URL, "http://".SERVER.":8088/ari/channels?endpoint=Local/s@banque&extension=".$tel."&context=ims&priority=1&timeout=30&api_key=asterisk:passer");
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
       curl_setopt($ch, CURLOPT_POST, 1);
       $result = curl_exec($ch);
        if (curl_errno($ch)) {
       echo 'Error:' . curl_error($ch);
                             }
       curl_close($ch);
}
$results=lecture();
foreach($results as $ligne)
{
	$tel=$ligne[tel];
        irilosi($tel);

}
header("location:../affichage/appelunique.php")
?>