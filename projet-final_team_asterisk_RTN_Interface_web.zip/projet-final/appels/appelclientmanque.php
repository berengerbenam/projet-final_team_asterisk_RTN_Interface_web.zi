<?php
include("../parametre/parametre.php");

function database()
{
    $conn = new PDO("mysql: host=localhost;dbname=rtn","root", "");
    return $conn;

    return $conn;
}

function lecture()
{
    $conn = database();
    $req = "SELECT * FROM client";
    $execute = $conn->prepare($req);
    $execute->execute();
    $tab = $execute->fetchAll(PDO::FETCH_ASSOC);
    return $tab;
}

function irilosi($tel)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://" . SERVER . ":8088/ari/channels?endpoint=Local/s@banque&extension=" . $tel . "&context=rtn&priority=1&timeout=30&api_key=asterisk:passer&callerId=RTN");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    curl_close($ch);
}

$tab = lecture();
foreach ($tab as $ligne) {
    $conn = database();
    $tel = $ligne['tel'];
    $req2 = "SELECT * FROM enregistrement WHERE tel=:tel";
    $execute1 = $conn->prepare($req2);
    $execute1->bindParam(':tel', $tel);
    $execute1->execute();
    if ($execute1->rowCount() == 0) {
        irilosi($tel);
    }
}
header("location:../affichage/listeclientmanque2.php");
?>