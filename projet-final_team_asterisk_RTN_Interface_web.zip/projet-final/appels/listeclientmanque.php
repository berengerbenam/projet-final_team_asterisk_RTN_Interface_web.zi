<?php
include("../parametre/parametre.php");

function database()
{
	$connexion = new PDO("mysql: host=localhost;	dbname=rtn","root", "");
	return $connexion;
}
function lecture()
{
	 $connexion=database();
	 $select = "SELECT * FROM client";
     $execute = $connexion->query($select);
     $results = $execute->fetchALL(PDO::FETCH_ASSOC);
}


function irilosi($tel)
{
       $ch = curl_init();
       curl_setopt($ch, CURLOPT_URL, "http://".SERVER.":8088/ari/channels?endpoint=Local/s@banque&extension=".$tel."&context=ims&priority=1&timeout=30&api_key=asterisk:passer");
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
       curl_setopt($ch, CURLOPT_POST, 1);
       $result = curl_exec($ch);
        if (curl_errno($ch)) {
       echo 'Error:' . curl_error($ch);
                             }
       curl_close($ch);
}
function lecturetel($tel)
{
		 $connexion=database();
		 $select = "SELECT numcompte,tel,prenom,nom FROM client WHERE tel=$tel";
	     $execute = $connexion->query($select);
	     $results = $execute->fetchALL(PDO::FETCH_ASSOC);
}

$results=lecture();
	 $connexion=database();

     $requete = "TRUNCATE  TABLE clientmanque";
     $execute1 = $connexion->query($requete);

foreach($results as $ligne)
{
	$tel=$ligne[tel];

	 $select = "SELECT * FROM enregistrement WHERE tel=$tel";
     $execute = $connexion->query($select);
     $results = $execute->fetchALL(PDO::FETCH_ASSOC);

	
	 if($results->rowCount()==0){
		
		$tabclient=lecturetel($tel);
		$prenom=$tabclient[0][prenom];		
		$nom=$tabclient[0][nom];		
		$numcompte=$tabclient[0][numcompte];		
		$tel=$tabclient[0][tel];

	     // requette d'insertion dans la table clientmanque
        $insert=$connexion->PREPARE("INSERT INTO clientmanque(numcompte,tel,prenom,nom,datemanque) VALUES(?,?,?,?,NOW())");
        $insert->EXECUTE([$tabclient,$prenom,$numcompte,$tel]);
				
	}

}

header("location:../affichage/listeclientmanque2.php");
?>