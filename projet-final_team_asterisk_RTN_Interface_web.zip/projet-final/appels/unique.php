<?php
$id=$_GET['id'];
include('../bd/connexion.php');
include('../parametre/parametre.php');

	 $select = "SELECT * FROM client WHERE id=$id";
     $execute = $connexion->query($select);
     $results = $execute->fetchALL(PDO::FETCH_ASSOC);
     $tel=$results[0]['tel'];

	 $ch = curl_init();
	 curl_setopt($ch, CURLOPT_URL, "http://".SERVER.":8088/ari/channels?endpoint=Local/s@banque&extension=".$tel."&context=ims&priority=1(".$tel.".gsm)"."&timeout=30&api_key=asterisk:passer");
	 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	 curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');

	 $response = curl_exec($ch);

	curl_close($ch);
	header("location:../affichage/appelunique.php");
?>