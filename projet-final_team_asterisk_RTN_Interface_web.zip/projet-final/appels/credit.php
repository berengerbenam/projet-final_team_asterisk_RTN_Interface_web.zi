<?php
$tel=$_REQUEST['tel'];

function database()
{
  $conn = new PDO("mysql: host=localhost; dbname=rtn","root", "");
  return $conn;
}
function lecture($tel)
{
	 $conn=database();
	 $select = "SELECT * FROM client WHERE tel='$tel'";
     $execute = $connexion->query($select);
     $results = $execute->fetchALL(PDO::FETCH_ASSOC);
     $doit=$results[0][credit];
     $message="Vous devez a la banque $doit";
	 return $message;
}
$message=lecture($tel);
print_r($message);
?>