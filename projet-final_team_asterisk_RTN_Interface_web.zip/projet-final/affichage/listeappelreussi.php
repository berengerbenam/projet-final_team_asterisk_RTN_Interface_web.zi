<?php
include('../parametre/secure.php');
authenticate();
    include("../bd/connexion.php");  
    $select = "SELECT * FROM cdr";
    $execute = $connexion->query($select);
    $results = $execute->fetchALL(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <title>Appels Manqués</title>
</head>
<body class="container">
   <?php if ($_SESSION['user']->typecompte =='admin') {?>
<?php
 include('../menu/menu.php');
?>
<h1 class="text-center">APPELS REUSSIS</h1>
<table id="maintable" class="display compact cell-border" cellspacing="0" width="100%">
    <thead>
    <tr>
        <th>ID</th>
        <th>Date</th>
        <th>Expéditeur</th>
        <th>destination</th>
        <th>Application</th>
        <th>Status</th>
        <th>Durée (secondes)</th>
    </tr>
    </thead>
    <tbody>
<?php
foreach($results as $ligne )
{?>
<?php
if ($ligne['disposition']=="ANSWERED" AND $ligne['lastapp']=="Dial"){
?>
    <tr>
        <th><?php echo $ligne['id']; ?></th>
        <th><?php echo $ligne['calldate']; ?></th>
        <th><?php echo $ligne['src']; ?></th>
        <th><?php echo $ligne['dst']; ?></th>
        <th><?php echo $ligne['lastapp']; ?></th>
        <th><?php if ($ligne['disposition']=="ANSWERED"){ echo "Appel réussi";} else echo "Appel manqué";?></th>
	<th><?php echo $ligne['duration']; ?></th>
    </tr>
<?php
}
?>

<?php
}
?> 
    </tbody>
    <tfoot style="background-color:#0080FF; color: #ffffff; font-size: 0.9em; ">
    <tr>
        <th>Id</th>
        <th>Date</th>
        <th>expéditeur</th>
        <th>Destination</th>
        <th>Application</th>
        <th>Status</th>
        <th>Durée</th>
    </tr>
    </tfoot>
</table>
<script type="text/javascript" src="../js/jquery-2.2.4.min.js"></script>
<script type="text/javascript" src="../js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="../js/jszip.min.js"></script>
<script type="text/javascript" src="../js/pdfmake.min.js"></script>
<script type="text/javascript" src="../js/vfs_fonts.js"></script>
<script type="text/javascript" src="../js/buttons.html5.min.js"></script>
<script type="text/javascript" src="../js/buttons.print.min.js"></script>
<script type="text/javascript" src="../js/app.js"></script>
<script type="text/javascript" src="../js/jquery.mark.min.js"></script>
<script type="text/javascript" src="../js/datatables.mark.js"></script>
<script type="text/javascript" src="../js/buttons.colVis.min.js"></script>
<?php } ?>
</body>
</html>