<?php
include('../parametre/secure.php');
authenticate();
     include("../bd/connexion.php");
     $tel=$_GET['tel'];  
     $select = "SELECT * FROM enregistrement WHERE tel=$tel";
     $execute = $connexion->query($select);
     $results = $execute->fetchALL(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link rel="stylesheet" type="text/css" href="../webfonts/all.css">
    <title>Plateforme de gestion</title>
</head>
<body class="container">
<?php if ($_SESSION['user']->typecompte =='admin') {?>
<?php
 include('../menu/menu.php');
?>
<h1 class="text-center"> LISTE DES ENREGISTREMENTS</h1>
<table id="maintable" class="display compact cell-border" cellspacing="0" width="100%">
    <thead>
    <tr>
        <th>Date</th>
        <th>Ecouter</th>
    </tr>
    </thead>
    <tbody>

<?php
	foreach($results as $ligne ){
		$chemin=$ligne['chemin'];
?>
	<tr>
        <th><?php echo $ligne['date']; ?></th>
	<th><audio controls><source src="../record/<?php echo $tel ?>/<?php echo $chemin ?>" type="audio/wav"></audio></th>	
    	</tr>
<?php
	}
?>
   </tbody>
    <tfoot style="background-color: #0080FF; color: #ffffff; font-size: 0.9em; ">
    <tr>
        <th>Numero</th>
        <th>Ecouter</th>
    </tr>
    </tfoot>
</table>
<script type="text/javascript" src="../js/jquery-2.2.4.min.js"></script>
<script type="text/javascript" src="../js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="../js/jszip.min.js"></script>
<script type="text/javascript" src="../js/pdfmake.min.js"></script>
<script type="text/javascript" src="../js/vfs_fonts.js"></script>
<script type="text/javascript" src="../js/buttons.html5.min.js"></script>
<script type="text/javascript" src="../js/buttons.print.min.js"></script>
<script type="text/javascript" src="../js/app.js"></script>
<script type="text/javascript" src="../js/jquery.mark.min.js"></script>
<script type="text/javascript" src="../js/datatables.mark.js"></script>
<script type="text/javascript" src="../js/buttons.colVis.min.js"></script>
<?php } ?>
</body>
</html>

