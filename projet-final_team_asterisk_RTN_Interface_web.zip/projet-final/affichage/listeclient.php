<?php
     require_once('../parametre/secure.php');
      authenticate();
    // inclusion du fichier de connexion
     include("../bd/connexion.php");  
     $select = "SELECT * FROM client";
     $execute = $connexion->query($select);
     $results = $execute->fetchALL(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link rel="stylesheet" type="text/css" href="../webfonts/all.css">
    <title>Plateforme de gestion</title>
</head>
<body class="container">
<?php if ($_SESSION['user']->typecompte =='admin') {?>
<?php
 include('../menu/menu.php');
?>
<h1 class="text-center"> LISTE DES CLIENTS</h1>
<a href="../formulaire/ajoutclient.php">
<button class="btn btn-outline-primary offset-5">Ajouter client</button></a>
<table id="maintable" class="display compact cell-border" cellspacing="0" width="100%">
    <thead>
    <tr>
        <th>ID</th>
        <th>NumCompte</th>
        <th>Prenom</th>
        <th>Nom</th>
        <th>Numéro</th>
        <th>Crédit</th>
        <th>DateAjout</th>
        <th>Modifier</th>
        <th>Supprimer</th>
    </tr>
    </thead>
    <tbody>

<?php
foreach($results as $ligne )
{?>
    <tr>
        <th><?php echo $ligne['id']; ?></th>
        <th><?php echo $ligne['numcompte']; ?></th>
        <th><?php echo $ligne['prenom']; ?></th>
        <th><?php echo $ligne['nom']; ?></th>
        <th><?php echo $ligne['tel']; ?></th>
        <th><?php echo $ligne['credit']; ?></th>
        <th><?php echo $ligne['dateajout']; ?></th>
        <th><a href="../formulaire/formmodiclient.php?id=<?php echo $ligne['id']?>"><i class="fas fa-edit offset-5"></i></th>
        <th><a onclick="return confirm('Voulez-vous vraiment supprimer ce client')" href="../suppression/suppclient.php?id=<?php echo $ligne['id']?>"><i class="fa fa-trash offset-5"></i></th>
    </tr>

<?php
}
?> 
    </tbody>
    <tfoot style="background-color: #0080FF; color: #ffffff; font-size: 0.8em; ">
    <tr>
        <th>Id</th>
        <th>Numcompte</th>
        <th>Telephone</th>
        <th>Prenom</th>
        <th>Nom</th>
        <th>Credit</th>
        <th>DateAjout</th>
    </tr>
    </tfoot>
</table>
<script type="text/javascript" src="../js/jquery-2.2.4.min.js"></script>
<script type="text/javascript" src="../js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="../js/jszip.min.js"></script>
<script type="text/javascript" src="../js/pdfmake.min.js"></script>
<script type="text/javascript" src="../js/vfs_fonts.js"></script>
<script type="text/javascript" src="../js/buttons.html5.min.js"></script>
<script type="text/javascript" src="../js/buttons.print.min.js"></script>
<script type="text/javascript" src="../js/app.js"></script>
<script type="text/javascript" src="../js/jquery.mark.min.js"></script>
<script type="text/javascript" src="../js/datatables.mark.js"></script>
<script type="text/javascript" src="../js/buttons.colVis.min.js"></script>
<?php } ?>
</body>
</html>