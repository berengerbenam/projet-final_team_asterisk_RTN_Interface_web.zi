<?php
include('../parametre/secure.php');
authenticate();
     // inclusion du fichier de connexion
     include("../bd/connexion1.php");
     $select = "SELECT * FROM ps_endpoints";
     $execute = $connexion->query($select);
     $results = $execute->fetchALL(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link rel="stylesheet" type="text/css" href="../webfonts/all.css">
    <title>Plateforme de gestion</title>
</head>
<body class="container">
<?php if ($_SESSION['user']->typecompte =='admin') {?>
<?php
 include('../menu/menu.php');
?>
<h1 class="text-center"> LISTE DES COMPTES</h1>
<a href="../formulaire/ajoutcomptepjsip.php">
<button class="btn btn-outline-primary offset-5">Ajouter Compte Pjsip</button></a>
<table id="maintable" class="display compact cell-border" cellspacing="0" width="100%">
    <thead>
    <tr>
        <th>Prenom</th>
        <th>Nom</th>
        <th>Telephone</th>
	    <th>Modifier</th>
	    <th>Supprimer</th>
    </tr>
    </thead>
    <tbody>
<?php
foreach($results as $ligne )
{
	$callerid=$ligne['callerid'];
    $liste=explode("<",trim($callerid));
    $prenomnom=$liste[0];
	$tabcomplet=explode(" ",$prenomnom);
	$l=count($tabcomplet);
	$prenom="";
	$n=$l-1;
	for ($i=0; $i<$n-1; $i++){
	$prenom=$prenom." ".$tabcomplet[$i];
	}
	$nom=$tabcomplet[$n-1];
        $telsup=$liste[1];
	$telsanssup=strtr($telsup,">"," ");
	$tel=trim($telsanssup);
?>
    <tr>
        <th><?php echo $prenom; ?></th>
        <th><?php echo $nom; ?></th>
        <th><?php echo $tel; ?></th>
	<th><a href="../formulaire/formmodicomptepjsip.php?id=<?php echo $ligne['id']?>"><i class="fas fa-edit offset-5"></i></th>
	<th><a onclick="return confirm('Voulez-vous vraiment supprimer ce compte')" href="../suppression/suppcomptepjsip.php?id=<?php echo $ligne['id']?>"><i class="fa fa-trash offset-5"></i></th>

    </tr>

<?php
}
?> 
    </tbody>
    <tfoot style="background-color: #0080FF; color: #ffffff; font-size: 0.8em; ">
    <tr>
        <th>Prenom</th>
        <th>Nom</th>
        <th>Téléphone</th>
    </tr>
    </tfoot>
</table>
<script type="text/javascript" src="../js/jquery-2.2.4.min.js"></script>
<script type="text/javascript" src="../js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="../js/jszip.min.js"></script>
<script type="text/javascript" src="../js/pdfmake.min.js"></script>
<script type="text/javascript" src="../js/vfs_fonts.js"></script>
<script type="text/javascript" src="../js/buttons.html5.min.js"></script>
<script type="text/javascript" src="../js/buttons.print.min.js"></script>
<script type="text/javascript" src="../js/app.js"></script>
<script type="text/javascript" src="../js/jquery.mark.min.js"></script>
<script type="text/javascript" src="../js/datatables.mark.js"></script>
<script type="text/javascript" src="../js/buttons.colVis.min.js"></script>
<?php } ?>
</body>
</html>
