<?php
include('../parametre/secure.php');
authenticate();
     include("../bd/connexion.php");  
     $select = "SELECT * FROM client";
     $execute = $connexion->query($select);
     $results = $execute->fetchALL(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link rel="stylesheet" type="text/css" href="../webfonts/all.css">
    <title>Plateforme de gestion</title>
</head>
<body class="container">
<?php if ($_SESSION['user']->typecompte =='admin') {?>
<?php
 include('../menu/menu.php');
?>
<h1 class="text-center"> APPEL CLIENTS</h1>
<div class="offset-5">
<a href="../appels/irikoue.php">
<button class="btn btn-outline-primary ">Appel tout le monde</button></a>
<a href="../appels/appelclientmanque.php">
<button class="btn btn-outline-danger ">Rappel clients</button></a>
</div>
<table id="maintable" class="display compact cell-border" cellspacing="0" width="100%">
    <thead>
    <tr>
        <th>ID</th>
        <th>NumCompte</th>
        <th>Téléphone</th>
        <th>Prenom</th>
        <th>Nom</th>
        <th>Crédit</th>
        <th>Appeler</th>
        <th>Ecouter</th>
    </tr>
    </thead>
    <tbody>
<?php
foreach($results as $ligne )
{?>

    <tr>
        <th><?php echo $ligne['id']; ?></th>
        <th><?php echo $ligne['numcompte']; ?></th>
        <th><?php echo $ligne['tel']; ?></th>
        <th><?php echo $ligne['prenom']; ?></th>
        <th><?php echo $ligne['nom']; ?></th>
        <th><?php echo $ligne['credit']; ?></th>
        <th><a href="../appels/unique.php?id=<?php echo $ligne['id'];?>"><i class="fa fa-phone offset-5"></i></th>
        <th><a href="ecouter.php?tel=<?php echo $ligne['tel'];?>"><i class="fa fa-play-circle offset-5"></i></th>
    </tr>

<?php
}
?> 
    </tbody>
    <tfoot style="background-color: #0080FF; color: #ffffff; font-size: 0.9em; ">
    <tr>
        <th>Id</th>
        <th>Prenom</th>
        <th>Nom</th>
        <th>Téléphone</th>
        <th>solde</th>
    </tr>
    </tfoot>
</table>
<script type="text/javascript" src="../js/jquery-2.2.4.min.js"></script>
<script type="text/javascript" src="../js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="../js/jszip.min.js"></script>
<script type="text/javascript" src="../js/pdfmake.min.js"></script>
<script type="text/javascript" src="../js/vfs_fonts.js"></script>
<script type="text/javascript" src="../js/buttons.html5.min.js"></script>
<script type="text/javascript" src="../js/buttons.print.min.js"></script>
<script type="text/javascript" src="../js/app.js"></script>
<script type="text/javascript" src="../js/jquery.mark.min.js"></script>
<script type="text/javascript" src="../js/datatables.mark.js"></script>
<script type="text/javascript" src="../js/buttons.colVis.min.js"></script>
<?php } ?>
</body>
</html>