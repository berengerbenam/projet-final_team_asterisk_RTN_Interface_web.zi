<?php
include('../parametre/secure.php');
authenticate();

include('../parametre/prenomnomtel.php');

include('../bd/connexion1.php');

    $idcompte = $_GET['id'];

    $select = "SELECT * FROM ps_endpoints WHERE id='$idcompte'";
    $execut = $connexion->query($select);
    $result = $execut->fetch(PDO::FETCH_ASSOC);

    $select1 = "SELECT * FROM ps_auths WHERE id='$idcompte'";
    $execut1 = $connexion->query($select1);
    $result1 = $execut1->fetch(PDO::FETCH_ASSOC);


$callerid=$result['callerid'];
$tab=prenomnomtel($callerid);
$prenom=$tab[0];
$nom=$tab[1];
$tel=$tab[2];
$mdp=$result1['password'];
?>
<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="../public/css/bootstrap.min.css">
        <title>Espace membres</title>
</head>
<body>
        <br><br>        
<?php if ($_SESSION['user']->typecompte =='admin') {?>
<div class="panel panel-primary  col-md-5 col-md-offset-3">
                <div class="panel panel-heading">
                        <h1 align="center">Modification</h1>
                </div>
                <div class="panel panel-body">
			<form action="../modification/modicomptepjsip.php?idco=<?php echo $result['id'] ?>" method="POST">
                                </div>
                        <div class="form-group">
                        <label for="prenom" class="label-control">Prenom</label>
                        <input type="text" class="form-control" name="prenom" value="<?php echo $prenom ?>">
                        </div>
                                <div class="form-group">
                                        <label for="nom" class="label-control">Nom</label>
                                        <input type="text" class="form-control" name="nom" value="<?php echo $nom ?>">
                                </div>
                                <div class="form-group">
                                        <label for="mot de passe" class="label-control">Mot de Passe</label>
                                        <input type="text" class="form-control" name="password" value="<?php echo $mdp ?>">
                                </div>
                                <div class="form-group">
                                        <label for="telephone" class="label-control">Telephone</label>
                                        <input type="text" class="form-control" name="telephone" value="<?php echo $tel ?>">
                                </div>
                                <div class="form-group" align="center">
                                        <button class="btn btn-primary" type="submit" name="modifier">Valider</button>
                                        <a href="../affichage/listecomptepjsip.php">
                                        <button class="btn btn-outline-danger">Retour</a></button>
                                </div>
                        </form>

		</div>
	</div>
</div>
<?php } ?>
</body>
</html>