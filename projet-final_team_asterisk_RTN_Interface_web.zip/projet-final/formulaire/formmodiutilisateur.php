<?php
include('../parametre/secure.php');
authenticate();
require('../bd/connexion.php');
if (isset($_GET['id'])) {
    $idutilisateur = $_GET['id'];
    $update = "SELECT  *  FROM utilisateurs WHERE id = ?";
    $ps = $connexion->prepare($update);
    $ps->execute([$idutilisateur]);
    $utilisateur = $ps->fetch();
    $prenom = $utilisateur['prenom'];
    $nom = $utilisateur['nom'];
    $matricule = $utilisateur['matricule'];
    $password = $utilisateur['password'];
    $typecompte = $utilisateur['typecompte'];
}
?>
<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="../public/css/bootstrap.min.css">
        <title>Espace membres</title>
</head>
<body>
    <br><br>    
    <?php if ($_SESSION['user']->typecompte =='admin') {?>
<div class="panel panel-primary  col-md-5 col-md-offset-3">
                <div class="panel panel-heading">
                    <h1 align="center">Modification</h1>
                </div>
                <div class="panel panel-body">
			<form action="../modification/modiutilisateur.php"  method="POST">
				<div class="form-group">
                	<input type="hidden" name="idu" value="<?php echo $utilisateur['id'] ?>">
            	</div>
				<div class="form-group">
					<label for="prenom" class="label-control">Prenom</label>
					<input type="text" class="form-control" name="prenom" value="<?php echo $utilisateur['prenom']?>">
				</div>
				<div class="form-group">
					<label for="nom" class="label-control">Nom</label>
					<input type="text" class="form-control" name="nom" value="<?php echo $utilisateur['nom']?>">
				</div>
				<div class="form-group">
					<label for="matricule" class="label-control">matricule</label>
					<input type="text" class="form-control" name="matricule" value="<?php echo $utilisateur['matricule']?>">
				</div>
				<div class="form-group">
                    <label for="password" class="label-control">password</label>
                    <input type="password" class="form-control" name="password">
				</div>
				<div class="form-group">
                        <label for="typecompte" class="label-control">Typecompte</label>
                        <input type="text" class="form-control" name="typecompte" value="<?php echo $utilisateur['typecompte']?>">
                </div>
				<div class="form-group" align="center">
					<button class="btn btn-success" type="submit" name="modifier" data-bs-dismiss="modal">Modifier</button>
					<button class="btn btn-danger" type="reset" name="annuler">Annuler</button>
				</div>
			</form>
		</div>
	</div>
</div>
<?php } ?>
</body>
</html>