<?php
include('../parametre/secure.php');
authenticate();
require('../bd/connexion.php');
if (isset($_GET['id'])) {
    $idclient = $_GET['id'];
    $update = "SELECT  *  FROM client WHERE id = ?";
    $ps = $connexion->prepare($update);
    $ps->execute([$idclient]);
    $client = $ps->fetch();
    $numcompte = $client['numcompte'];
    $tel = $client['tel'];
    $prenom = $client['prenom'];
    $nom = $client['nom'];
    $credit = $client['credit'];
}
?>
<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="../public/css/bootstrap.min.css">
        <title>Espace membres</title>
</head>
<body>
    <br><br>    
    <?php if ($_SESSION['user']->typecompte =='admin') {?>
<div class="panel panel-primary  col-md-5 col-md-offset-3">
                <div class="panel panel-heading">
                        <h1 align="center">Modification</h1>
                </div>
                <div class="panel panel-body">
			<form action="../modification/modiclient.php" class="form" method="POST">
				<div class="form-group">
               <input type="hidden" name="id" value="<?php echo $client['id'] ?>">
            </div>
				<div class="form-group">
                    <label for="numcompte" class="label-control">NumCompte</label>
                    <input type="text" class="form-control" name="numcompte" value="<?php echo $client['numcompte']?>">
				</div>
				<div class="form-group">
                        <label for="telephone" class="label-control">Téléphone</label>
                        <input type="text" class="form-control" name="telephone" value="<?php echo $client['tel']?>">
                </div>
				<div class="form-group">
					<label for="prenom" class="label-control">Prenom</label>
					<input type="text" class="form-control" name="prenom" value="<?php echo $client['prenom']?>">
				</div>
				<div class="form-group">
					<label for="nom" class="label-control">Nom</label>
					<input type="text" class="form-control" name="nom" value="<?php echo $client['nom']?>">
				</div>
				<div class="form-group">
					<label for="credit" class="label-control">Credit</label>
					<input type="text" class="form-control" name="credit" value="<?php echo $client['credit']?>">
				</div>
				<div class="form-group" align="center">
					<button class="btn btn-primary" type="submit" name="modifier" data-bs-dismiss="modal">Modifier</button>
					<button class="btn btn-danger" type="reset" name="annuler">Annuler</button>
				</div>
			</form>
		</div>
	</div>
</div>
<?php } ?>
</body>
</html>