<?php
include('../parametre/secure.php');
authenticate();

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../public/css/bootstrap.min.css">
	<title>ajouter client</title>
</head>
<body>
	<br><br>	
	<?php if ($_SESSION['user']->typecompte =='admin') {?>
<div class="panel panel-primary col-md-5 col-md-offset-3 ">
		<div class="panel panel-heading">
			<h1 align="center">Ajouter Utilisateur</h1>
		</div>
		<div class="panel panel-body">
			<form action="../traitement/traitutilisateur.php" method="POST">
				<div class="form-group">
					<label for="prenom" class="label-control">Prenom</label>
					<input type="text" class="form-control" name="prenom">
				</div>
				<div class="form-group">
					<label for="nom" class="label-control">Nom</label>
					<input type="text" class="form-control" name="nom">
				</div>
				<div>
                        <div class="form-group">
                        <label for="matricule" class="label-control">matricule</label>
                        <input type="text" class="form-control" name="matricule">
                </div>
				<div class="form-group">
					<label for="password" class="label-control">password</label>
					<input type="password" class="form-control" name="password">
				</div>
					<div class="form-group">
					<label for="typecompte" class="label-control">typecompte</label>
					<input type="text" class="form-control" name="typecompte">
				</div>
				<div class="form-group" align="center">
					<button class="btn btn-primary" type="submit" name="valider">Valider</button>
					<a href="../affichage/listeutilisateur.php">
				<button class="btn btn-outline-danger">Retour</a></button>
				</div>
			</form>
		</div>
	</div>
</div>
</div>
<?php } ?>
</body>
</html>