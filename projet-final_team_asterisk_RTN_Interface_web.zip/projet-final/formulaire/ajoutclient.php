<?php
include('../parametre/secure.php');
authenticate();

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../public/css/bootstrap.min.css">
	<title>ajouter client</title>
</head>
<body>
	<br><br>	
	<?php if ($_SESSION['user']->typecompte =='admin') {?>
<div class="panel panel-primary  col-md-5 col-md-offset-3 ">
		<div class="panel panel-heading">
			<h1 align="center">Ajouter Client</h1>
		</div>
		<div class="panel panel-body">
			<form action="../traitement/traitclient.php" method="POST">
				</div>
                        <div class="form-group">
                        <label for="numcompte" class="label-control">NumCompte</label>
                        <input type="text" class="form-control" name="numcompte">
                </div>
				<div class="form-group">
					<label for="prenom" class="label-control">Prenom</label>
					<input type="text" class="form-control" name="prenom">
				</div>
				<div class="form-group">
					<label for="nom" class="label-control">Nom</label>
					<input type="text" class="form-control" name="nom">
				</div>
				<div class="form-group">
					<label for="telephone" class="label-control">Telephone</label>
					<input type="text" class="form-control" name="telephone">
				</div>
					<div class="form-group">
					<label for="credit" class="label-control">Credit</label>
					<input type="text" class="form-control" name="credit">
				</div>
				<div class="form-group" align="center">
					<button class="btn btn-primary" type="submit" name="valider">Valider</button>
					<a href="../affichage/listeclient.php">
					<button class="btn btn-outline-danger">Retour</a></button>
				</div>
			</form>
		</div>
	</div>
</div>
</div>
<?php } ?>
</body>
</html>