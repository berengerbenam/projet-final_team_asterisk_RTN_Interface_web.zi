<?php
require('../bd/connexion.php');
if (isset($_POST['modifier'])) {
	$idu=$_POST['idu'];
	$prenom = $_POST['prenom'];
	$nom = $_POST['nom'];
	$matricule = $_POST['matricule'];
	$password = $_POST['password'];
	$typecompte = $_POST['typecompte'];

    $requete=$connexion->prepare("UPDATE utilisateurs SET prenom=? ,nom=? ,matricule=?,password=? ,typecompte=? ,dateajout=NOW() WHERE id=?");
									
    $valeurs=array($prenom,$nom,$matricule,$password,$typecompte,$idu);			
	$resultat=$requete->execute($valeurs);
    header('Location:../affichage/listeutilisateur.php');
}