<?php
include('../bd/connexion1.php');
if (isset($_POST['modifier'])) {
	$idco=$_GET['idco'];
	$prenom = $_POST['prenom'];
	$telephone = $_POST['telephone'];
	$nom = $_POST['nom'];
	$password = $_POST['password'];
	$boite = $telephone."@default";
	$callerid=$prenom." ".$nom." "."<".$telephone.">";


	$update = "UPDATE ps_aors SET id='$telephone' WHERE id='$idco'";
	$connexion->exec($update);

	$update = "UPDATE ps_auths SET id='$telephone', password='$password', username='$telephone' WHERE id='$idco'";
	$connexion->exec($update);

	$update = "UPDATE ps_endpoints SET id='$telephone', aors='$telephone', auth='$telephone', mailboxes='$boite',callerid='$callerid' WHERE id='$idco'";
	$connexion->exec($update);

header("location:../affichage/listecomptepjsip.php");

}
?>