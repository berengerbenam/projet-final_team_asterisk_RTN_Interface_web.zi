<?php
require('../bd/connexion.php');
if (isset($_POST['modifier'])) {
	$id=$_POST['id'];
	$numcompte = $_POST['numcompte'];
	$telephone = $_POST['telephone'];
	$prenom = $_POST['prenom'];
	$nom = $_POST['nom'];
	$credit = $_POST['credit'];

    $requete=$connexion->prepare("UPDATE client SET numcompte=?,tel=?,prenom=?,nom=? ,credit=?,dateajout=NOW() WHERE id=?");
									
    $valeurs=array($numcompte,$telephone,$prenom,$nom,$credit,$id);			
	$resultat=$requete->execute($valeurs);
    header('Location:../affichage/listeclient.php');
}