-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 12 avr. 2023 à 12:25
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `rtn`
--

-- --------------------------------------------------------

--
-- Structure de la table `cdr`
--

CREATE TABLE `cdr` (
  `calldate` datetime NOT NULL DEFAULT '2023-03-27 00:00:00',
  `clid` varchar(80) NOT NULL DEFAULT '',
  `src` varchar(80) NOT NULL DEFAULT '',
  `dst` varchar(80) NOT NULL DEFAULT '',
  `dcontext` varchar(80) NOT NULL DEFAULT '',
  `channel` varchar(80) NOT NULL DEFAULT '',
  `dstchannel` varchar(80) NOT NULL DEFAULT '',
  `lastapp` varchar(80) NOT NULL DEFAULT '',
  `lastdata` varchar(80) NOT NULL DEFAULT '',
  `duration` int(11) NOT NULL DEFAULT 0,
  `billsec` int(11) NOT NULL DEFAULT 0,
  `disposition` varchar(45) NOT NULL DEFAULT '',
  `amaflags` int(11) NOT NULL DEFAULT 0,
  `accountcode` varchar(20) NOT NULL DEFAULT '',
  `userfield` varchar(255) NOT NULL DEFAULT '',
  `uniqueid` varchar(32) NOT NULL DEFAULT '',
  `linkedid` varchar(32) NOT NULL DEFAULT '',
  `sequence` varchar(32) NOT NULL DEFAULT '',
  `peeraccount` varchar(32) NOT NULL DEFAULT '',
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Déchargement des données de la table `cdr`
--

INSERT INTO `cdr` (`calldate`, `clid`, `src`, `dst`, `dcontext`, `channel`, `dstchannel`, `lastapp`, `lastdata`, `duration`, `billsec`, `disposition`, `amaflags`, `accountcode`, `userfield`, `uniqueid`, `linkedid`, `sequence`, `peeraccount`, `id`) VALUES
('2023-04-03 11:46:07', '\"Adoum\" <1001>', '1001', '1000', 'ims', 'SIP/1001-00000000', 'SIP/1000-00000001', 'Dial', 'SIP/1000,10', 5, 3, 'ANSWERED', 3, '', '', '1680522367.0', '', '', '', 91),
('2023-04-03 12:00:25', '\"Adoum\" <1001>', '1001', '1000', 'ims', 'SIP/1001-00000002', 'SIP/1000-00000003', 'Dial', 'SIP/1000,10', 5, 0, 'BUSY', 3, '', '', '1680523225.3', '', '', '', 92),
('2023-04-03 12:37:19', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-00000000;1', 'SIP/1000-00000004', 'Dial', 'SIP/1000,10', 8, 8, 'BUSY', 3, '', '', '1680525439.6', '', '', '', 93),
('2023-04-03 12:37:19', '\"Mbaye samb\" <1000>', '1000', 's', 'banque', 'Local/s@banque-00000000;2', '', 'AGI', 'googletts.agi,\"Tapez 1 pour repondre et valider par etoile\",fr,any', 18, 18, 'ANSWERED', 3, '', '', '1680525439.7', '', '', '', 94),
('2023-04-03 12:39:25', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-00000001;1', 'SIP/1000-00000005', 'Dial', 'SIP/1000,10', 8, 8, 'BUSY', 3, '', '', '1680525565.11', '', '', '', 95),
('2023-04-03 12:39:25', '\"Mbaye samb\" <1000>', '1000', 's', 'banque', 'Local/s@banque-00000001;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 18, 18, 'ANSWERED', 3, '', '', '1680525565.12', '', '', '', 96),
('2023-04-03 12:39:55', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-00000002;1', 'SIP/1000-00000006', 'Dial', 'SIP/1000,10', 2, 2, 'BUSY', 3, '', '', '1680525595.16', '', '', '', 97),
('2023-04-03 12:39:55', '\"Mbaye samb\" <1000>', '1000', 's', 'banque', 'Local/s@banque-00000002;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 13, 13, 'ANSWERED', 3, '', '', '1680525595.17', '', '', '', 98),
('2023-04-03 12:41:50', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-00000003;1', 'SIP/1000-00000007', 'Dial', 'SIP/1000,10', 6, 6, 'BUSY', 3, '', '', '1680525710.21', '', '', '', 99),
('2023-04-03 12:41:50', '\"Mbaye samb\" <1000>', '1000', 's', 'banque', 'Local/s@banque-00000003;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 16, 16, 'ANSWERED', 3, '', '', '1680525710.22', '', '', '', 100),
('2023-04-03 12:45:34', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-00000005;1', 'SIP/1001-00000009', 'Dial', 'SIP/1001,10', 5, 5, 'BUSY', 3, '', '', '1680525934.28', '', '', '', 101),
('2023-04-03 12:45:34', '\"Adoum\" <1001>', '1001', 's', 'banque', 'Local/s@banque-00000005;2', '', 'AGI', 'googletts.agi,\"Vous devez a la banque 200000\",fr,any', 15, 15, 'ANSWERED', 3, '', '', '1680525934.29', '', '', '', 102),
('2023-04-03 12:45:34', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-00000004;1', 'SIP/1000-00000008', 'Dial', 'SIP/1000,10', 6, 6, 'BUSY', 3, '', '', '1680525934.26', '', '', '', 103),
('2023-04-03 12:45:34', '\"Mbaye samb\" <1000>', '1000', 's', 'banque', 'Local/s@banque-00000004;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 16, 16, 'ANSWERED', 3, '', '', '1680525934.27', '', '', '', 104),
('2023-04-03 13:37:34', '\"Mbaye samb\" <1000>', '1000', '1', 'banque', 'Local/s@banque-00000006;2', '', 'Set', 'resultat=\n\nERREUR : Le rÃ©pertoire existe dÃ©jÃ .', 14, 14, 'ANSWERED', 3, '', '', '1680529054.37', '', '', '', 105),
('2023-04-03 13:37:34', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-00000006;1', 'SIP/1000-0000000a', 'Dial', 'SIP/1000,10', 14, 14, 'ANSWERED', 3, '', '', '1680529054.36', '', '', '', 106),
('2023-04-03 13:38:20', '\"Mbaye samb\" <1000>', '1000', '1', 'banque', 'Local/s@banque-00000007;2', '', 'Set', 'resultat=\n\nERREUR : Le rÃ©pertoire existe dÃ©jÃ .', 13, 12, 'ANSWERED', 3, '', '', '1680529100.42', '', '', '', 107),
('2023-04-03 13:38:20', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-00000007;1', 'SIP/1000-0000000b', 'Dial', 'SIP/1000,10', 13, 13, 'ANSWERED', 3, '', '', '1680529100.41', '', '', '', 108),
('2023-04-03 15:04:30', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-00000009;1', 'SIP/1001-0000000d', 'Dial', 'SIP/1001,10', 4, 3, 'BUSY', 3, '', '', '1680534270.48', '', '', '', 109),
('2023-04-03 15:04:30', '\"Adoum\" <1001>', '1001', 's', 'banque', 'Local/s@banque-00000009;2', '', 'AGI', 'googletts.agi,\"Vous devez a la banque 200000\",fr,any', 14, 14, 'ANSWERED', 3, '', '', '1680534270.49', '', '', '', 110),
('2023-04-03 15:04:30', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-00000008;1', 'SIP/1000-0000000c', 'Dial', 'SIP/1000,10', 10, 10, 'BUSY', 3, '', '', '1680534270.46', '', '', '', 111),
('2023-04-03 15:04:30', '\"Mbaye samb\" <1000>', '1000', 's', 'banque', 'Local/s@banque-00000008;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 20, 20, 'ANSWERED', 3, '', '', '1680534270.47', '', '', '', 112),
('2023-04-03 15:06:40', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-0000000a;1', 'SIP/1000-0000000e', 'Dial', 'SIP/1000,10', 6, 6, 'BUSY', 3, '', '', '1680534400.56', '', '', '', 113),
('2023-04-03 15:06:40', '\"Mbaye samb\" <1000>', '1000', 's', 'banque', 'Local/s@banque-0000000a;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 16, 16, 'ANSWERED', 3, '', '', '1680534400.57', '', '', '', 114),
('2023-04-03 15:06:40', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-0000000b;1', 'SIP/1001-0000000f', 'Dial', 'SIP/1001,10', 8, 8, 'BUSY', 3, '', '', '1680534400.59', '', '', '', 115),
('2023-04-03 15:06:40', '\"Adoum\" <1001>', '1001', 's', 'banque', 'Local/s@banque-0000000b;2', '', 'AGI', 'googletts.agi,\"Quand comptez vous payer ?\",fr,any', 18, 18, 'ANSWERED', 3, '', '', '1680534400.60', '', '', '', 116),
('2023-04-03 15:08:31', '\"Adoum\" <1001>', '1001', 's', 'banque', 'Local/s@banque-0000000d;2', '', 'AGI', 'googletts.agi,\"Tapez 1 pour repondre et valider par etoile\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680534511.69', '', '', '', 117),
('2023-04-03 15:08:31', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-0000000d;1', 'SIP/1001-00000011', 'Dial', 'SIP/1001,10', 10, 10, 'NO ANSWER', 3, '', '', '1680534511.68', '', '', '', 118),
('2023-04-03 15:08:31', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-0000000c;1', 'SIP/1000-00000010', 'Dial', 'SIP/1000,10', 6, 6, 'BUSY', 3, '', '', '1680534511.66', '', '', '', 119),
('2023-04-03 15:08:31', '\"Mbaye samb\" <1000>', '1000', 's', 'banque', 'Local/s@banque-0000000c;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 16, 16, 'ANSWERED', 3, '', '', '1680534511.67', '', '', '', 120),
('2023-04-03 15:18:04', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-0000000e;1', 'SIP/1000-00000012', 'Dial', 'SIP/1000,10', 5, 5, 'BUSY', 3, '', '', '1680535084.76', '', '', '', 121),
('2023-04-03 15:18:04', '\"Mbaye samb\" <1000>', '1000', 's', 'banque', 'Local/s@banque-0000000e;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 15, 15, 'ANSWERED', 3, '', '', '1680535084.77', '', '', '', 122),
('2023-04-03 15:18:04', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-0000000f;1', 'SIP/1001-00000013', 'Dial', 'SIP/1001,10', 8, 7, 'BUSY', 3, '', '', '1680535084.78', '', '', '', 123),
('2023-04-03 15:18:04', '\"Adoum\" <1001>', '1001', 's', 'banque', 'Local/s@banque-0000000f;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 18, 18, 'ANSWERED', 3, '', '', '1680535084.79', '', '', '', 124),
('2023-04-03 15:18:21', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-00000010;1', 'SIP/1000-00000014', 'Dial', 'SIP/1000,10', 5, 5, 'BUSY', 3, '', '', '1680535101.84', '', '', '', 125),
('2023-04-03 15:18:21', '\"Mbaye samb\" <1000>', '1000', 's', 'banque', 'Local/s@banque-00000010;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 15, 15, 'ANSWERED', 3, '', '', '1680535101.85', '', '', '', 126),
('2023-04-03 15:18:21', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-00000011;1', 'SIP/1001-00000015', 'Dial', 'SIP/1001,10', 7, 7, 'BUSY', 3, '', '', '1680535101.86', '', '', '', 127),
('2023-04-03 15:18:21', '\"Adoum\" <1001>', '1001', 's', 'banque', 'Local/s@banque-00000011;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 17, 17, 'ANSWERED', 3, '', '', '1680535101.87', '', '', '', 128),
('2023-04-03 15:19:58', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-00000013;1', 'SIP/1001-00000017', 'Dial', 'SIP/1001,10', 10, 10, 'NO ANSWER', 3, '', '', '1680535198.98', '', '', '', 129),
('2023-04-03 15:19:58', '\"Adoum\" <1001>', '1001', 's', 'banque', 'Local/s@banque-00000013;2', '', 'AGI', 'googletts.agi,\"Tapez 1 pour repondre et valider par etoile\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680535198.99', '', '', '', 130),
('2023-04-03 15:19:58', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-00000012;1', 'SIP/1000-00000016', 'Dial', 'SIP/1000,10', 10, 10, 'BUSY', 3, '', '', '1680535198.96', '', '', '', 131),
('2023-04-03 15:19:58', '\"Mbaye samb\" <1000>', '1000', 's', 'banque', 'Local/s@banque-00000012;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 20, 20, 'ANSWERED', 3, '', '', '1680535198.97', '', '', '', 132),
('2023-04-03 15:21:50', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-00000015;1', 'SIP/1001-00000019', 'Dial', 'SIP/1001,10', 3, 3, 'BUSY', 3, '', '', '1680535310.108', '', '', '', 133),
('2023-04-03 15:21:50', '\"Adoum\" <1001>', '1001', 's', 'banque', 'Local/s@banque-00000015;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 13, 13, 'ANSWERED', 3, '', '', '1680535310.109', '', '', '', 134),
('2023-04-03 15:21:50', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-00000014;1', 'SIP/1000-00000018', 'Dial', 'SIP/1000,10', 4, 4, 'BUSY', 3, '', '', '1680535310.106', '', '', '', 135),
('2023-04-03 15:21:50', '\"Mbaye samb\" <1000>', '1000', 's', 'banque', 'Local/s@banque-00000014;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 14, 14, 'ANSWERED', 3, '', '', '1680535310.107', '', '', '', 136),
('2023-04-03 15:34:23', '\"Mbaye samb\" <1000>', '1000', '1', 'banque', 'Local/s@banque-00000016;2', '', 'Set', 'resultat=\n\nERREUR : Le rÃ©pertoire existe dÃ©jÃ .', 28, 28, 'ANSWERED', 3, '', '', '1680536063.117', '', '', '', 137),
('2023-04-03 15:34:23', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-00000016;1', 'SIP/1000-0000001a', 'Dial', 'SIP/1000,10', 28, 28, 'ANSWERED', 3, '', '', '1680536063.116', '', '', '', 138),
('2023-04-03 15:43:24', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-00000017;1', 'SIP/1001-0000001b', 'Dial', 'SIP/1001,10', 13, 13, 'ANSWERED', 3, '', '', '1680536604.121', '', '', '', 139),
('2023-04-03 15:43:24', '\"Adoum\" <1001>', '1001', 's', 'banque', 'Local/s@banque-00000017;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 13, 13, 'ANSWERED', 3, '', '', '1680536604.122', '', '', '', 140),
('2023-04-03 15:43:54', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-00000018;1', 'SIP/1001-0000001c', 'Dial', 'SIP/1001,10', 20, 20, 'ANSWERED', 3, '', '', '1680536634.126', '', '', '', 141),
('2023-04-03 15:43:54', '\"Adoum\" <1001>', '1001', '1', 'banque', 'Local/s@banque-00000018;2', '', 'Record', '/var/www/html/projetfinal/record/1001/1001-03-04-2023_15-44-07.wav,,,t', 20, 20, 'ANSWERED', 3, '', '', '1680536634.127', '', '', '', 142),
('2023-04-03 15:44:32', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-00000019;1', 'SIP/1001-0000001d', 'Dial', 'SIP/1001,10', 17, 17, 'ANSWERED', 3, '', '', '1680536672.131', '', '', '', 143),
('2023-04-03 15:44:32', '\"Adoum\" <1001>', '1001', '1', 'banque', 'Local/s@banque-00000019;2', '', 'Set', 'resultat=\n\nERREUR : Le rÃ©pertoire existe dÃ©jÃ .', 17, 16, 'ANSWERED', 3, '', '', '1680536672.132', '', '', '', 144),
('2023-04-03 16:07:41', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-0000001a;1', '', 'Dial', 'SIP/1000,10', 10, 10, 'ANSWERED', 3, '', '', '1680538061.136', '', '', '', 145),
('2023-04-03 16:07:41', '\"Adoum\" <1001>', '1001', 's', 'banque', 'Local/s@banque-0000001b;2', '', 'AGI', 'googletts.agi,\"Tapez 1 pour repondre et valider par etoile\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680538061.139', '', '', '', 146),
('2023-04-03 16:07:41', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-0000001b;1', 'SIP/1001-0000001e', 'Dial', 'SIP/1001,10', 10, 10, 'NO ANSWER', 3, '', '', '1680538061.138', '', '', '', 147),
('2023-04-03 16:07:41', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-0000001c;1', '', 'Dial', 'SIP/1003,10', 10, 10, 'ANSWERED', 3, '', '', '1680538061.140', '', '', '', 148),
('2023-04-03 16:07:41', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-0000001d;1', '', 'Dial', 'SIP/1004,10', 10, 10, 'ANSWERED', 3, '', '', '1680538061.142', '', '', '', 149),
('2023-04-03 16:07:41', '\"\" <>', '', 's', 'banque', 'Local/s@banque-0000001a;2', '', 'AGI', 'googletts.agi,\"Bonjour  Monsieur \",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680538061.137', '', '', '', 150),
('2023-04-03 16:07:41', '\"\" <>', '', 's', 'banque', 'Local/s@banque-0000001d;2', '', 'AGI', 'googletts.agi,\"Bonjour  Monsieur \",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680538061.143', '', '', '', 151),
('2023-04-03 16:07:41', '\"\" <>', '', 's', 'banque', 'Local/s@banque-0000001c;2', '', 'AGI', 'googletts.agi,\"Bonjour  Monsieur \",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680538061.141', '', '', '', 152),
('2023-04-03 16:07:55', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-0000001e;1', '', 'Dial', 'SIP/1000,10', 10, 10, 'ANSWERED', 3, '', '', '1680538075.153', '', '', '', 153),
('2023-04-03 16:07:55', '\"\" <>', '', 's', 'banque', 'Local/s@banque-0000001e;2', '', 'AGI', 'googletts.agi,\"Bonjour  Monsieur \",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680538075.154', '', '', '', 154),
('2023-04-03 16:07:55', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-00000021;1', '', 'Dial', 'SIP/1004,10', 10, 10, 'ANSWERED', 3, '', '', '1680538075.160', '', '', '', 155),
('2023-04-03 16:07:55', '\"\" <>', '', 's', 'banque', 'Local/s@banque-00000021;2', '', 'AGI', 'googletts.agi,\"Bonjour  Monsieur \",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680538075.161', '', '', '', 156),
('2023-04-03 16:07:55', '\"Adoum\" <1001>', '1001', 's', 'banque', 'Local/s@banque-0000001f;2', '', 'WaitExten', '', 17, 17, 'ANSWERED', 3, '', '', '1680538075.156', '', '', '', 157),
('2023-04-03 16:07:55', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-0000001f;1', 'SIP/1001-0000001f', 'Dial', 'SIP/1001,10', 7, 7, 'BUSY', 3, '', '', '1680538075.155', '', '', '', 158),
('2023-04-03 16:07:55', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-00000020;1', 'SIP/1003-00000020', 'Dial', 'SIP/1003,10', 9, 9, 'BUSY', 3, '', '', '1680538075.157', '', '', '', 159),
('2023-04-03 16:07:55', '\"\" <>', '', 's', 'banque', 'Local/s@banque-00000020;2', '', 'AGI', 'googletts.agi,\"Vous devez a la banque\",fr,any', 19, 19, 'ANSWERED', 3, '', '', '1680538075.158', '', '', '', 160),
('2023-04-03 16:26:30', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-00000022;1', 'SIP/1003-00000021', 'Dial', 'SIP/1003,10', 10, 10, 'NO ANSWER', 3, '', '', '1680539190.171', '', '', '', 161),
('2023-04-03 16:26:30', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-00000023;1', '', 'Dial', 'SIP/1004,10', 10, 10, 'ANSWERED', 3, '', '', '1680539190.173', '', '', '', 162),
('2023-04-03 16:26:30', '\"\" <>', '', 's', 'banque', 'Local/s@banque-00000022;2', '', 'AGI', 'googletts.agi,\"Vous devez a la banque\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680539190.172', '', '', '', 163),
('2023-04-03 16:26:30', '\"\" <>', '', 's', 'banque', 'Local/s@banque-00000023;2', '', 'AGI', 'googletts.agi,\"Vous devez a la banque\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680539190.175', '', '', '', 164),
('2023-04-03 16:28:29', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-00000025;1', 'SIP/1004-00000023', 'Dial', 'SIP/1004,10', 10, 10, 'NO ANSWER', 3, '', '', '1680539309.182', '', '', '', 165),
('2023-04-03 16:28:29', '\"\" <>', '', 's', 'banque', 'Local/s@banque-00000025;2', '', 'AGI', 'googletts.agi,\"Vous devez a la banque\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680539309.183', '', '', '', 166),
('2023-04-03 16:28:29', '\"\" <>', '', '1', 'banque', 'Local/s@banque-00000024;2', '', 'Set', 'resultat=\n\nERREUR : Le rÃ©pertoire existe dÃ©jÃ .', 23, 23, 'ANSWERED', 3, '', '', '1680539309.181', '', '', '', 167),
('2023-04-03 16:28:29', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-00000024;1', 'SIP/1003-00000022', 'Dial', 'SIP/1003,10', 23, 23, 'ANSWERED', 3, '', '', '1680539309.180', '', '', '', 168),
('2023-04-03 16:28:56', '\"\" <>', '', 's', 'banque', 'Local/s@banque-00000026;2', '', 'AGI', 'googletts.agi,\"Tapez 1 pour repondre et valider par etoile\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680539336.191', '', '', '', 169),
('2023-04-03 16:28:56', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-00000026;1', 'SIP/1003-00000024', 'Dial', 'SIP/1003,10', 10, 10, 'NO ANSWER', 3, '', '', '1680539336.190', '', '', '', 170),
('2023-04-03 16:28:56', '\"\" <>', '', 's', 'banque', 'Local/s@banque-00000027;2', '', 'WaitExten', '', 17, 17, 'ANSWERED', 3, '', '', '1680539336.193', '', '', '', 171),
('2023-04-03 16:28:56', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-00000027;1', 'SIP/1004-00000025', 'Dial', 'SIP/1004,10', 7, 7, 'BUSY', 3, '', '', '1680539336.192', '', '', '', 172),
('2023-04-03 16:33:41', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-00000029;1', 'SIP/1004-00000027', 'Dial', 'SIP/1004,10', 9, 9, 'BUSY', 3, '', '', '1680539621.202', '', '', '', 173),
('2023-04-03 16:33:41', '\"Ismaila\" <1004>', '1004', 's', 'banque', 'Local/s@banque-00000029;2', '', 'AGI', 'googletts.agi,\"Vous devez a la banque 45000\",fr,any', 19, 19, 'ANSWERED', 3, '', '', '1680539621.203', '', '', '', 174),
('2023-04-03 16:33:41', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-00000028;1', 'SIP/1003-00000026', 'Dial', 'SIP/1003,10', 35, 35, 'ANSWERED', 3, '', '', '1680539621.200', '', '', '', 175),
('2023-04-03 16:33:41', '\"berenger\" <1003>', '1003', '1', 'banque', 'Local/s@banque-00000028;2', '', 'Set', 'resultat=\n\nERREUR : Le rÃ©pertoire existe dÃ©jÃ .', 35, 35, 'ANSWERED', 3, '', '', '1680539621.201', '', '', '', 176),
('2023-04-03 16:34:35', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-0000002a;1', 'SIP/1004-00000028', 'Dial', 'SIP/1004,10', 10, 10, 'NO ANSWER', 3, '', '', '1680539675.210', '', '', '', 177),
('2023-04-03 16:34:35', '\"Ismaila\" <1004>', '1004', 's', 'banque', 'Local/s@banque-0000002a;2', '', 'AGI', 'googletts.agi,\"Vous devez a la banque 45000\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680539675.211', '', '', '', 178),
('2023-04-03 16:34:51', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-0000002b;1', 'SIP/1004-00000029', 'Dial', 'SIP/1004,10', 27, 27, 'ANSWERED', 3, '', '', '1680539691.215', '', '', '', 179),
('2023-04-03 16:34:51', '\"Ismaila\" <1004>', '1004', '1', 'banque', 'Local/s@banque-0000002b;2', '', 'Set', 'resultat=\n\nERREUR : Le rÃ©pertoire existe dÃ©jÃ .', 27, 27, 'ANSWERED', 3, '', '', '1680539691.216', '', '', '', 180),
('2023-04-03 16:46:12', '\"berenger\" <1003>', '1003', '1', 'banque', 'Local/s@banque-0000002c;2', '', 'Set', 'resultat=\n\nERREUR : Le rÃ©pertoire existe dÃ©jÃ .', 15, 15, 'ANSWERED', 3, '', '', '1680540372.221', '', '', '', 181),
('2023-04-03 16:46:12', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-0000002c;1', 'SIP/1003-0000002a', 'Dial', 'SIP/1003,10', 15, 15, 'ANSWERED', 3, '', '', '1680540372.220', '', '', '', 182),
('2023-04-03 17:17:16', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-0000002d;1', 'SIP/1004-0000002b', 'Dial', 'SIP/1004,10', 10, 10, 'NO ANSWER', 3, '', '', '1680542236.225', '', '', '', 183),
('2023-04-03 17:17:16', '\"Ismaila\" <1004>', '1004', 's', 'banque', 'Local/s@banque-0000002d;2', '', 'AGI', 'googletts.agi,\"Tapez 1 pour repondre et valider par etoile\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680542236.226', '', '', '', 184),
('2023-04-03 17:17:52', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-0000002e;1', 'SIP/1004-0000002c', 'Dial', 'SIP/1004,10', 16, 16, 'ANSWERED', 3, '', '', '1680542272.230', '', '', '', 185),
('2023-04-03 17:17:52', '\"Ismaila\" <1004>', '1004', '1', 'banque', 'Local/s@banque-0000002e;2', '', 'Set', 'resultat=\n\nERREUR : Le rÃ©pertoire existe dÃ©jÃ .', 16, 16, 'ANSWERED', 3, '', '', '1680542272.231', '', '', '', 186),
('2023-04-03 18:04:22', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-0000002f;1', '', 'Dial', 'SIP/1000,10', 10, 10, 'ANSWERED', 3, '', '', '1680545062.235', '', '', '', 187),
('2023-04-03 18:04:22', '\"\" <>', '', 's', 'banque', 'Local/s@banque-0000002f;2', '', 'AGI', 'googletts.agi,\"Tapez 1 pour repondre et valider par etoile\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680545062.236', '', '', '', 188),
('2023-04-03 18:04:22', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-00000030;1', 'SIP/1001-0000002d', 'Dial', 'SIP/1001,10', 10, 10, 'NO ANSWER', 3, '', '', '1680545062.237', '', '', '', 189),
('2023-04-03 18:04:22', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-00000031;1', '', 'Dial', 'SIP/1003,10', 10, 10, 'ANSWERED', 3, '', '', '1680545062.239', '', '', '', 190),
('2023-04-03 18:04:22', '\"\" <>', '', 's', 'banque', 'Local/s@banque-00000031;2', '', 'AGI', 'googletts.agi,\"Tapez 1 pour repondre et valider par etoile\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680545062.240', '', '', '', 191),
('2023-04-03 18:04:22', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-00000032;1', 'SIP/1004-0000002e', 'Dial', 'SIP/1004,10', 10, 10, 'NO ANSWER', 3, '', '', '1680545062.242', '', '', '', 192),
('2023-04-03 18:04:22', '\"Ismaila\" <1004>', '1004', 's', 'banque', 'Local/s@banque-00000032;2', '', 'AGI', 'googletts.agi,\"Tapez 1 pour repondre et valider par etoile\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680545062.243', '', '', '', 193),
('2023-04-03 18:04:22', '\"Nasry\" <1001>', '1001', 's', 'banque', 'Local/s@banque-00000030;2', '', 'AGI', 'googletts.agi,\"Bonjour  Monsieur Nasry\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680545062.238', '', '', '', 194),
('2023-04-03 18:04:48', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-00000033;1', '', 'Dial', 'SIP/1003,10', 10, 10, 'ANSWERED', 3, '', '', '1680545088.253', '', '', '', 195),
('2023-04-03 18:04:48', '\"\" <>', '', 's', 'banque', 'Local/s@banque-00000033;2', '', 'AGI', 'googletts.agi,\"Tapez 1 pour repondre et valider par etoile\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680545088.254', '', '', '', 196),
('2023-04-03 18:04:50', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-00000034;1', '', 'Dial', 'SIP/1003,10', 10, 10, 'ANSWERED', 3, '', '', '1680545090.255', '', '', '', 197),
('2023-04-03 18:04:50', '\"\" <>', '', 's', 'banque', 'Local/s@banque-00000034;2', '', 'AGI', 'googletts.agi,\"Tapez 1 pour repondre et valider par etoile\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680545090.256', '', '', '', 198),
('2023-04-03 18:06:11', '\"\" <>', '', '1000', 'ims', 'Local/s@banque-00000035;1', '', 'Dial', 'SIP/1000,10', 10, 10, 'ANSWERED', 3, '', '', '1680545171.261', '', '', '', 199),
('2023-04-03 18:06:11', '\"\" <>', '', 's', 'banque', 'Local/s@banque-00000035;2', '', 'AGI', 'googletts.agi,\"Quand comptez vous payer ?\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680545171.262', '', '', '', 200),
('2023-04-03 18:06:11', '\"\" <>', '', '1001', 'ims', 'Local/s@banque-00000036;1', 'SIP/1001-0000002f', 'Dial', 'SIP/1001,10', 10, 10, 'NO ANSWER', 3, '', '', '1680545171.263', '', '', '', 201),
('2023-04-03 18:06:11', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-00000038;1', 'SIP/1004-00000031', 'Dial', 'SIP/1004,10', 10, 10, 'NO ANSWER', 3, '', '', '1680545171.267', '', '', '', 202),
('2023-04-03 18:06:11', '\"Ismaila\" <1004>', '1004', 's', 'banque', 'Local/s@banque-00000038;2', '', 'AGI', 'googletts.agi,\"Vous devez a la banque 45000\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680545171.269', '', '', '', 203),
('2023-04-03 18:06:11', '\"Nasry\" <1001>', '1001', 's', 'banque', 'Local/s@banque-00000036;2', '', 'AGI', 'googletts.agi,\"Bonjour  Monsieur Nasry\",fr,any', 14, 14, 'ANSWERED', 3, '', '', '1680545171.264', '', '', '', 204),
('2023-04-03 18:06:11', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-00000037;1', 'SIP/1003-00000030', 'Dial', 'SIP/1003,10', 9, 9, 'BUSY', 3, '', '', '1680545171.265', '', '', '', 205),
('2023-04-03 18:06:11', '\"berenger\" <1003>', '1003', 's', 'banque', 'Local/s@banque-00000037;2', '', 'AGI', 'googletts.agi,\"Appuyez sur diÃ¨se si vous souhaitez rÃ©Ã©couter ceÂ  message\",f', 19, 19, 'ANSWERED', 3, '', '', '1680545171.266', '', '', '', 206),
('2023-04-03 18:06:28', '\"berenger\" <1003>', '1003', 's', 'banque', 'Local/s@banque-00000039;2', '', 'AGI', 'googletts.agi,\"Tapez 1 pour repondre et valider par etoile\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680545188.279', '', '', '', 207),
('2023-04-03 18:06:28', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-00000039;1', 'SIP/1003-00000032', 'Dial', 'SIP/1003,10', 10, 10, 'NO ANSWER', 3, '', '', '1680545188.278', '', '', '', 208),
('2023-04-03 18:08:48', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-0000003a;1', 'SIP/1003-00000033', 'Dial', 'SIP/1003,10', 13, 13, 'ANSWERED', 3, '', '', '1680545328.285', '', '', '', 209),
('2023-04-03 18:08:48', '\"berenger\" <1003>', '1003', '1', 'banque', 'Local/s@banque-0000003a;2', '', 'Set', 'resultat=\n\nERREUR : Le rÃ©pertoire existe dÃ©jÃ .', 13, 13, 'ANSWERED', 3, '', '', '1680545328.286', '', '', '', 210),
('2023-04-03 18:22:44', '\"berenger\" <1003>', '1003', 's', 'banque', 'Local/s@banque-0000003b;2', '', 'AGI', 'googletts.agi,\"Tapez 1 pour repondre et valider par etoile\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680546164.291', '', '', '', 211),
('2023-04-03 18:22:44', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-0000003b;1', 'SIP/1003-00000034', 'Dial', 'SIP/1003,10', 10, 10, 'NO ANSWER', 3, '', '', '1680546164.290', '', '', '', 212),
('2023-04-03 18:22:44', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-0000003c;1', 'SIP/1004-00000035', 'Dial', 'SIP/1004,10', 10, 10, 'NO ANSWER', 3, '', '', '1680546164.293', '', '', '', 213),
('2023-04-03 18:22:44', '\"Ismaila\" <1004>', '1004', 's', 'banque', 'Local/s@banque-0000003c;2', '', 'AGI', 'googletts.agi,\"Tapez 1 pour repondre et valider par etoile\",fr,any', 10, 10, 'ANSWERED', 3, '', '', '1680546164.294', '', '', '', 214),
('2023-04-03 18:23:50', '\"berenger\" <1003>', '1003', '1', 'banque', 'Local/s@banque-0000003d;2', '', 'Set', 'resultat=\n\nERREUR : Le rÃ©pertoire existe dÃ©jÃ .', 15, 15, 'ANSWERED', 3, '', '', '1680546230.301', '', '', '', 215),
('2023-04-03 18:23:50', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-0000003d;1', 'SIP/1003-00000036', 'Dial', 'SIP/1003,10', 15, 15, 'ANSWERED', 3, '', '', '1680546230.300', '', '', '', 216),
('2023-04-03 18:23:50', '\"Ismaila\" <1004>', '1004', 's', 'banque', 'Local/s@banque-0000003e;2', '', 'WaitExten', '', 19, 19, 'ANSWERED', 3, '', '', '1680546230.303', '', '', '', 217),
('2023-04-03 18:23:50', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-0000003e;1', 'SIP/1004-00000037', 'Dial', 'SIP/1004,10', 9, 9, 'BUSY', 3, '', '', '1680546230.302', '', '', '', 218),
('2023-04-03 18:30:56', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-0000003f;1', 'SIP/1004-00000038', 'Dial', 'SIP/1004,10', 17, 17, 'ANSWERED', 3, '', '', '1680546656.310', '', '', '', 219),
('2023-04-03 18:30:56', '\"Ismaila\" <1004>', '1004', '1', 'banque', 'Local/s@banque-0000003f;2', '', 'Set', 'resultat=\n\nERREUR : Le rÃ©pertoire existe dÃ©jÃ .', 17, 17, 'ANSWERED', 3, '', '', '1680546656.311', '', '', '', 220),
('2023-04-03 18:34:45', '\"Ismaila\" <1004>', '1004', '1', 'banque', 'Local/s@banque-00000041;2', '', 'Set', 'resultat=\n\nERREUR : Le rÃ©pertoire existe dÃ©jÃ .', 14, 14, 'ANSWERED', 3, '', '', '1680546885.318', '', '', '', 221),
('2023-04-03 18:34:45', '\"\" <>', '', '1004', 'ims', 'Local/s@banque-00000041;1', 'SIP/1004-0000003a', 'Dial', 'SIP/1004,10', 14, 14, 'ANSWERED', 3, '', '', '1680546885.317', '', '', '', 222),
('2023-04-03 18:34:45', '\"berenger\" <1003>', '1003', 's', 'banque', 'Local/s@banque-00000040;2', '', 'WaitExten', '', 19, 19, 'ANSWERED', 3, '', '', '1680546885.316', '', '', '', 223),
('2023-04-03 18:34:45', '\"\" <>', '', '1003', 'ims', 'Local/s@banque-00000040;1', 'SIP/1003-00000039', 'Dial', 'SIP/1003,10', 9, 9, 'BUSY', 3, '', '', '1680546885.315', '', '', '', 224);

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `numcompte` varchar(30) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `prenom` varchar(70) DEFAULT NULL,
  `nom` varchar(70) DEFAULT NULL,
  `credit` varchar(30) DEFAULT NULL,
  `dateajout` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id`, `numcompte`, `tel`, `prenom`, `nom`, `credit`, `dateajout`) VALUES
(1, 'banque1000', '1000', 'mbaye ', 'samb', '400000', '2023-04-07 12:13:42'),
(2, 'banque1001', '1001', 'nasry', 'ahamadi', '200000', '2023-04-07 12:15:17'),
(4, 'banque1003', '1003', 'berenger', 'benam', '190000', '2023-04-07 12:15:21'),
(5, 'banque1004', '1004', 'Ismaila', 'Fall', '45000', '2023-04-07 12:15:24'),
(6, 'banque1005', '1005', 'Samuel', 'Ouya', '200000', '2023-04-07 12:15:28'),
(7, 'banque1006', '1006', 'Ahamadi', 'Nasry', '20000', '2023-04-07 12:15:32');

-- --------------------------------------------------------

--
-- Structure de la table `clientmanque`
--

CREATE TABLE `clientmanque` (
  `id` int(11) NOT NULL,
  `numcompte` varchar(30) DEFAULT NULL,
  `tel` varchar(30) DEFAULT NULL,
  `prenom` varchar(30) DEFAULT NULL,
  `nom` varchar(30) DEFAULT NULL,
  `datemanque` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Déchargement des données de la table `clientmanque`
--

INSERT INTO `clientmanque` (`id`, `numcompte`, `tel`, `prenom`, `nom`, `datemanque`) VALUES
(1, 'banque1003', '1003', 'berenger', 'benam', '0000-00-00 00:00:00'),
(2, 'banque1005', '1005', 'Samuel', 'Ouya', '0000-00-00 00:00:00'),
(3, 'banque1006', '1006', 'Ahamadi', 'Nasry', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `enregistrement`
--

CREATE TABLE `enregistrement` (
  `id` int(11) NOT NULL,
  `tel` varchar(30) DEFAULT NULL,
  `chemin` varchar(50) DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Déchargement des données de la table `enregistrement`
--

INSERT INTO `enregistrement` (`id`, `tel`, `chemin`, `date`) VALUES
(1, '1000', '1000-03-04-2023_13-37-44.wav', '2023-04-03 13:37:49'),
(2, '1000', '1000-03-04-2023_13-38-29.wav', '2023-04-03 13:38:32'),
(3, '1000', '1000-03-04-2023_15-34-49.wav', '2023-04-03 15:34:52'),
(4, '1001', '1001-03-04-2023_15-44-44.wav', '2023-04-03 15:44:49'),
(13, '1004', '1004-03-04-2023_18-34-56.wav', '2023-04-03 18:34:59');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `id` int(11) NOT NULL,
  `prenom` varchar(70) DEFAULT NULL,
  `nom` varchar(70) DEFAULT NULL,
  `matricule` varchar(70) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `typecompte` varchar(30) DEFAULT NULL,
  `dateajout` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `prenom`, `nom`, `matricule`, `password`, `typecompte`, `dateajout`) VALUES
(1, 'Samuel', 'Ouya', 'matemploye1', 'passer', 'admin', '2023-04-08 11:17:23'),
(4, 'Ahamadi', 'Nasry', 'matemploye2', 'passer', 'admin', '2023-04-08 08:39:26');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `cdr`
--
ALTER TABLE `cdr`
  ADD PRIMARY KEY (`id`),
  ADD KEY `calldate` (`calldate`),
  ADD KEY `dst` (`dst`),
  ADD KEY `accountcode` (`accountcode`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `clientmanque`
--
ALTER TABLE `clientmanque`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `enregistrement`
--
ALTER TABLE `enregistrement`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `cdr`
--
ALTER TABLE `cdr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=225;

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `clientmanque`
--
ALTER TABLE `clientmanque`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `enregistrement`
--
ALTER TABLE `enregistrement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
