<?php
	define('url','mysql:host=localhost;dbname=sauvasterisk;charset=utf8');
	define('user','root');
	define('password','');
	try {
	 	$connexion=new PDO (url,user,password);
	 	//echo "connexion reussie";
	 } catch (PDOException $e) {
	 	echo "echec de connexion".$e->getMessage();
	 } 
?>