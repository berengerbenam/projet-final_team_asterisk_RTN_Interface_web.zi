<?php
include('../parametre/secure.php');
authenticate();

?>
<!DOCTYPE html>
<html>
<head>
    <title>menu</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" type="text/css" href="../css/webfonts/all.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <!-- **************** BOOTSTRAP -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
</head>
<body style="background-color: #e9ecef;">
<?php if ($_SESSION['user']->typecompte =='admin') {?>
    <!-- ********************** HEADER -->
        <div class="page-header" id="anene">
            <h4><marquee behavior ="alternate">BIENVENUE SUR LA PLATEFORME DE GESTION </marquee></h4>
        </div>
    <!-- *********************** NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <!-- boutton responsive -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- logo -->
        <a class="navbar-brand" href="accueil.php">
            <img src="../img/logo.jpg" style="width: 20%; margin-left: 8%;">
        </a>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item active">
                <a class="nav-link text-primary" href="../affichage/historique.php">Historique Appels <span class="sr-only">(current)</span></a>
	      </li>
            <li class="nav-item active">
                <a class="nav-link text-primary" href="../affichage/listeappelreussi.php"> Appels Réussis <span class="sr-only">(current)</span></a>
              </li>
        <li class="nav-item active">
                <a class="nav-link text-primary" href="../affichage/listeappelmanque.php">Appels Manqués <span class="sr-only">(current)</span></a>
	      </li>
        <li class="nav-item active">
                <a class="nav-link text-primary" href="../affichage/listeclient.php">Liste Clients<span class="sr-only">(current)</span></a>
	     </li>
        <li class="nav-item active">
                <a class="nav-link text-primary" href="../affichage/listeutilisateur.php">Liste Operateurs<span class="sr-only">(current)</span></a>
       </li>
       <li class="nav-item active">
                <a class="nav-link text-primary" href="../affichage/listecomptepjsip.php">Liste comptes<span class="sr-only">(current)</span></a>
       </li>
        <li class="nav-item active">
                <a class="nav-link text-primary" href="../appels/listeclientmanque1.php">Clients no réagis<span class="sr-only">(current)</span></a>
        </li>
               <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-primary" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Services
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="../affichage/appelunique.php">Appels</a>
                </div>
              </li>
               <div style="margin-left: 150px;">
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-success" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="fa fa-user-circle-o"></span>&nbsp
                <?= $_SESSION['user']->prenom.' '.$_SESSION['user']->nom;?>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                   <a class="nav-link text-primary" href="../parametre/profil.php?id=<?= $_SESSION['user']->id;?>">
                    <span class="fa fa-vcard-o"></span>&nbsp
              Mon Compte
                </a>
                  <a class="nav-link text-danger" href="../logout.php" role="button">
                    <span class="fa fa-sign-out"></span>&nbsp
               Deconnexion
                </a>
                </div>
              </li>
            </ul>
        </div>
    </nav>
<br>
            <!-- ******************** DEBUT CAROUSEL -->
<div style="margin-left: 8%;">
  <div class="row">
     <!--  first grid -->
      <div class="col-2 col1">
        <!-- contenu -->
      </div>
      <!-- second grid -->
      <div class="col-11" style="margin-left: 1%; margin-right: 1%; ">             
            <!-- indicateurs -->
       <div id="carousel-example-2" class="carousel slide carousel-fade" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carousel-example-2" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-2" data-slide-to="1"></li>
            <li data-target="#carousel-example-2" data-slide-to="2"></li>
          </ol>
            <!-- images défilantes -->
        <div class="carousel-inner">
            <div class="carousel-item active">
              <img class="d-block w-100 rounded" src="../img/nas.jpeg" alt="First slide" style="width: 100px; height: 400px;">
            </div>
            <div class="carousel-item">
              <img class="d-block w-100 rounded" src="../img/na.jpeg" alt="Second slide"  style="width: 50px; height: 400px;">
            </div>
            <div class="carousel-item">
              <img class="d-block w-100 rounded" src="../img/na.jpeg" alt="Third slide"  style="width: 50px; height: 400px;">
            </div>
        </div>
            <!-- flèche next and previous -->
          <a class="carousel-control-prev" href="#carousel-example-2" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Précedent</span>
          </a>
          <a class="carousel-control-next" href="#carousel-example-2" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Suivant</span>
          </a>
        </div>
    </div>
    <!-- third grid  -->
    <div class="col-2 col2">
      <!-- CONTENU -->
    </div>
  </div>
<br>
<!-- Footer -->
<footer class="text-center text-lg-start bg-light text-muted">
  <!-- Section: Social media -->
  <section
    class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom"
  >
    <!-- Left -->
    <div class="me-5 d-none d-lg-block">
      <span>Connectez-vous avec nous sur les réseaux sociaux:</span>
    </div>
    <!-- Right -->
    <div>
      <a href="https://www.facebook.com" class="me-4 text-reset">
        <i class="fab fa-facebook-f"></i>
      </a>
      <a href="" class="me-4 text-reset">
        <i class="fab fa-twitter"></i>
      </a>
      <a href="https://mail.google.com" class="me-4 text-reset">
        <i class="fab fa-google"></i>
      </a>
      <a href="https://www.instagram.com/?hl=fr" class="me-4 text-reset">
        <i class="fab fa-instagram"></i>
      </a>
      <a href="https://www.whatsapp.com/?lang=fr" class="me-4 text-reset">
        <i class="fab fa-whatsapp"></i>
      </a>
      <a href="" class="me-4 text-reset">
        <i class="fab fa-github"></i>
      </a>
    </div>
    <!-- Right -->
  </section>
  <!-- Section: Social media -->
  <!-- Section: Links  -->
  <section class="">
    <div class="container text-center text-md-start mt-5">
      <!-- Grid row -->
      <div class="row mt-3">
        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
          <!-- Content -->
          <h6 class="text-uppercase fw-bold mb-4">
            <i class="fas fa-gem me-3"></i>
        </div>
        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">
            Products
          </h6>
          <p>
            <a href="#!" class="text-reset">Angular</a>
          </p>
          <p>
            <a href="#!" class="text-reset">React</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Vue</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Laravel</a>
          </p>
        </div>
        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">
            Useful links
          </h6>
          <p>
            <a href="#!" class="text-reset">Pricing</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Settings</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Orders</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Help</a>
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">
            Contact
          </h6>
        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
  </section>
  <!-- Section: Links  -->
<footer class="text-center text-white" style="background-color: #caced1;">
  <!-- Grid container -->
  <div class="container p-4">
    <!-- Section: Images -->
    <section class="">
      <div class="row">
        <div class="col-lg-2 col-md-12 mb-4 mb-md-0">
          <div
            class="bg-image hover-overlay ripple shadow-1-strong rounded"
            data-ripple-color="light"
          >
            <img
              src="https://mdbootstrap.com/img/new/fluid/city/113.jpg"
              class="w-100"
            />
            <a href="#!">
              <div
                class="mask"
                style="background-color: rgba(251, 251, 251, 0.2);"
              ></div>
            </a>
          </div>
        </div>
        <div class="col-lg-2 col-md-12 mb-4 mb-md-0">
          <div
            class="bg-image hover-overlay ripple shadow-1-strong rounded"
            data-ripple-color="light"
          >
            <img
              src="https://mdbootstrap.com/img/new/fluid/city/111.jpg"
              class="w-100"
            />
            <a href="#!">
              <div
                class="mask"
                style="background-color: rgba(251, 251, 251, 0.2);"
              ></div>
            </a>
          </div>
        </div>
        <div class="col-lg-2 col-md-12 mb-4 mb-md-0">
          <div
            class="bg-image hover-overlay ripple shadow-1-strong rounded"
            data-ripple-color="light"
          >
            <img
              src="https://mdbootstrap.com/img/new/fluid/city/112.jpg"
              class="w-100"
            />
            <a href="#!">
              <div
                class="mask"
                style="background-color: rgba(251, 251, 251, 0.2);"
              ></div>
            </a>
          </div>
        </div>
        <div class="col-lg-2 col-md-12 mb-4 mb-md-0">
          <div
            class="bg-image hover-overlay ripple shadow-1-strong rounded"
            data-ripple-color="light"
          >
            <img
              src="https://mdbootstrap.com/img/new/fluid/city/114.jpg"
              class="w-100"
            />
            <a href="#!">
              <div
                class="mask"
                style="background-color: rgba(251, 251, 251, 0.2);"
              ></div>
            </a>
          </div>
        </div>
        <div class="col-lg-2 col-md-12 mb-4 mb-md-0">
          <div
            class="bg-image hover-overlay ripple shadow-1-strong rounded"
            data-ripple-color="light"
          >
            <img
              src="https://mdbootstrap.com/img/new/fluid/city/115.jpg"
              class="w-100"
            />
            <a href="#!">
              <div
                class="mask"
                style="background-color: rgba(251, 251, 251, 0.2);"
              ></div>
            </a>
          </div>
        </div>
        <div class="col-lg-2 col-md-12 mb-4 mb-md-0">
          <div
            class="bg-image hover-overlay ripple shadow-1-strong rounded"
            data-ripple-color="light"
          >
            <img
              src="https://mdbootstrap.com/img/new/fluid/city/116.jpg"
              class="w-100"
            />
            <a href="#!">
              <div
                class="mask"
                style="background-color: rgba(251, 251, 251, 0.2);"
              ></div>
            </a>
          </div>
        </div>
      </div>
    </section>
    <!-- Section: Images -->
  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-4" style="background-color: black;">
    ©2023 Copyright:
    <a class="text-reset fw-bold" href="https://mdbootstrap.com/">labortn.com</a>
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->
<script src="https://kit.fontawesome.com/dd8c49730d.js" crossorigin="anonymous"></script>
            <!-- ******************* JAVASCRIPT -->
<!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
        <!-- temps de défilement des photo -->
<script type="text/javascript">
    $('.carousel').carousel({
        interval: 2000
})
</script>
<?php } ?> 
</body>
</html>