<!DOCTYPE html>
<html>
<head>
    <title>menu</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" type="text/css" href="../css/webfonts/all.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <!-- **************** BOOTSTRAP -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
</head>
<body style="background-color: #e9ecef;">
<nav class="navbar navbar-expand-lg navbar-light bg-white">
        <!-- boutton responsive -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- logo -->
        <a class="navbar-brand" href="../menu/accueil.php">
            <img src="../img/logo.jpg" style="width: 20%; margin-left: 8%;">
        </a>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item active">
                <a class="nav-link text-primary" href="../affichage/historique.php">Historique Appels <span class="sr-only">(current)</span></a>
              </li>
            <li class="nav-item active">
                <a class="nav-link text-primary" href="../affichage/listeappelreussi.php"> Appels Réussis <span class="sr-only">(current)</span></a>
              </li>
        <li class="nav-item active">
                <a class="nav-link text-primary" href="../affichage/listeappelmanque.php">Appels Manqués <span class="sr-only">(current)</span></a>
              </li>
        <li class="nav-item active">
                <a class="nav-link text-primary" href="../affichage/listeclient.php">Liste Clients<span class="sr-only">(current)</span></a>
	     </li>
       <li class="nav-item active">
                <a class="nav-link text-primary" href="../affichage/listeutilisateur.php">Liste Operateurs<span class="sr-only">(current)</span></a>
       </li>
       <li class="nav-item active">
                <a class="nav-link text-primary" href="../affichage/listecomptepjsip.php">Liste Comptes<span class="sr-only">(current)</span></a>
       </li>
        </li>
        <li class="nav-item active">
                <a class="nav-link text-primary" href="../appels/listeclientmanque1.php">Clients no réagis<span class="sr-only">(current)</span></a>
        </li>
               <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-primary" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Services
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="../affichage/appelunique.php">Appels</a>
                </div>
              </li>
               <div style="margin-left: 150px;">
               <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-success" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="fa fa-user-circle-o"></span>&nbsp
                <?= $_SESSION['user']->prenom.' '.$_SESSION['user']->nom;?>
                            <span class="caret"></span>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                   <a class="nav-link text-primary" href="../parametre/profil.php?id=<?= $_SESSION['user']->id;?>">
                    <span class="fa fa-vcard-o"></span>&nbsp
              Mon Compte
                </a>
                  <a class="nav-link text-danger" href="../logout.php" role="button">
                    <span class="fa fa-sign-out"></span>&nbsp
               Deconnexion
                </a>
                </div>
            </ul>
        </div>
    </nav>
<script src="https://kit.fontawesome.com/dd8c49730d.js" crossorigin="anonymous"></script>
            <!-- ******************* JAVASCRIPT -->
<!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
        <!-- temps de défilement des photo -->
<script type="text/javascript">
    $('.carousel').carousel({
        interval: 2000
})
</script>
</body>    
</html>        